-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 27, 2022 at 03:06 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `learningsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `badges`
--

DROP TABLE IF EXISTS `badges`;
CREATE TABLE IF NOT EXISTS `badges` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `point` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `meta_keyword` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
CREATE TABLE IF NOT EXISTS `courses` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lession_count` int(11) DEFAULT NULL,
  `course_for` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_time` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `courses_slug_unique` (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

DROP TABLE IF EXISTS `districts`;
CREATE TABLE IF NOT EXISTS `districts` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `division_id` int(11) NOT NULL,
  `bn_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `user_id`, `name`, `division_id`, `bn_name`, `lat`, `lon`, `url`, `status`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Comilla', 1, 'কুমিল্লা', '23.4682747', '91.1788135', 'www.comilla.gov.bd', 1, NULL, NULL),
(2, NULL, 'Feni', 1, 'ফেনী', '23.023231', '91.3840844', 'www.feni.gov.bd', 1, NULL, NULL),
(3, NULL, 'Brahmanbaria', 1, 'ব্রাহ্মণবাড়িয়া', '23.9570904', '91.1119286', 'www.brahmanbaria.gov.bd', 1, NULL, NULL),
(4, NULL, 'Rangamati', 1, 'রাঙ্গামাটি', NULL, NULL, 'www.rangamati.gov.bd', 1, NULL, NULL),
(5, NULL, 'Noakhali', 1, 'নোয়াখালী', '22.869563', '91.099398', 'www.noakhali.gov.bd', 1, NULL, NULL),
(6, NULL, 'Chandpur', 1, 'চাঁদপুর', '23.2332585', '90.6712912', 'www.chandpur.gov.bd', 1, NULL, NULL),
(7, NULL, 'Lakshmipur', 1, 'লক্ষ্মীপুর', '22.942477', '90.841184', 'www.lakshmipur.gov.bd', 1, NULL, NULL),
(8, NULL, 'Chattogram', 1, 'চট্টগ্রাম', '22.335109', '91.834073', 'www.chittagong.gov.bd', 1, NULL, NULL),
(9, NULL, 'Coxsbazar', 1, 'কক্সবাজার', NULL, NULL, 'www.coxsbazar.gov.bd', 1, NULL, NULL),
(10, NULL, 'Khagrachhari', 1, 'খাগড়াছড়ি', '23.119285', '91.984663', 'www.khagrachhari.gov.bd', 1, NULL, NULL),
(11, NULL, 'Bandarban', 1, 'বান্দরবান', '22.1953275', '92.2183773', 'www.bandarban.gov.bd', 1, NULL, NULL),
(12, NULL, 'Sirajganj', 2, 'সিরাজগঞ্জ', '24.4533978', '89.7006815', 'www.sirajganj.gov.bd', 1, NULL, NULL),
(13, NULL, 'Pabna', 2, 'পাবনা', '23.998524', '89.233645', 'www.pabna.gov.bd', 1, NULL, NULL),
(14, NULL, 'Bogura', 2, 'বগুড়া', '24.8465228', '89.377755', 'www.bogra.gov.bd', 1, NULL, NULL),
(15, NULL, 'Rajshahi', 2, 'রাজশাহী', NULL, NULL, 'www.rajshahi.gov.bd', 1, NULL, NULL),
(16, NULL, 'Natore', 2, 'নাটোর', '24.420556', '89.000282', 'www.natore.gov.bd', 1, NULL, NULL),
(17, NULL, 'Joypurhat', 2, 'জয়পুরহাট', NULL, NULL, 'www.joypurhat.gov.bd', 1, NULL, NULL),
(18, NULL, 'Chapainawabganj', 2, 'চাঁপাইনবাবগঞ্জ', '24.5965034', '88.2775122', 'www.chapainawabganj.gov.bd', 1, NULL, NULL),
(19, NULL, 'Naogaon', 2, 'নওগাঁ', NULL, NULL, 'www.naogaon.gov.bd', 1, NULL, NULL),
(20, NULL, 'Jashore', 3, 'যশোর', '23.16643', '89.2081126', 'www.jessore.gov.bd', 1, NULL, NULL),
(21, NULL, 'Satkhira', 3, 'সাতক্ষীরা', NULL, NULL, 'www.satkhira.gov.bd', 1, NULL, NULL),
(22, NULL, 'Meherpur', 3, 'মেহেরপুর', '23.762213', '88.631821', 'www.meherpur.gov.bd', 1, NULL, NULL),
(23, NULL, 'Narail', 3, 'নড়াইল', '23.172534', '89.512672', 'www.narail.gov.bd', 1, NULL, NULL),
(24, NULL, 'Chuadanga', 3, 'চুয়াডাঙ্গা', '23.6401961', '88.841841', 'www.chuadanga.gov.bd', 1, NULL, NULL),
(25, NULL, 'Kushtia', 3, 'কুষ্টিয়া', '23.901258', '89.120482', 'www.kushtia.gov.bd', 1, NULL, NULL),
(26, NULL, 'Magura', 3, 'মাগুরা', '23.487337', '89.419956', 'www.magura.gov.bd', 1, NULL, NULL),
(27, NULL, 'Khulna', 3, 'খুলনা', '22.815774', '89.568679', 'www.khulna.gov.bd', 1, NULL, NULL),
(28, NULL, 'Bagerhat', 3, 'বাগেরহাট', '22.651568', '89.785938', 'www.bagerhat.gov.bd', 1, NULL, NULL),
(29, NULL, 'Jhenaidah', 3, 'ঝিনাইদহ', '23.5448176', '89.1539213', 'www.jhenaidah.gov.bd', 1, NULL, NULL),
(30, NULL, 'Jhalakathi', 4, 'ঝালকাঠি', NULL, NULL, 'www.jhalakathi.gov.bd', 1, NULL, NULL),
(31, NULL, 'Patuakhali', 4, 'পটুয়াখালী', '22.3596316', '90.3298712', 'www.patuakhali.gov.bd', 1, NULL, NULL),
(32, NULL, 'Pirojpur', 4, 'পিরোজপুর', NULL, NULL, 'www.pirojpur.gov.bd', 1, NULL, NULL),
(33, NULL, 'Barisal', 4, 'বরিশাল', NULL, NULL, 'www.barisal.gov.bd', 1, NULL, NULL),
(34, NULL, 'Bhola', 4, 'ভোলা', '22.685923', '90.648179', 'www.bhola.gov.bd', 1, NULL, NULL),
(35, NULL, 'Barguna', 4, 'বরগুনা', NULL, NULL, 'www.barguna.gov.bd', 1, NULL, NULL),
(36, NULL, 'Sylhet', 5, 'সিলেট', '24.8897956', '91.8697894', 'www.sylhet.gov.bd', 1, NULL, NULL),
(37, NULL, 'Moulvibazar', 5, 'মৌলভীবাজার', '24.482934', '91.777417', 'www.moulvibazar.gov.bd', 1, NULL, NULL),
(38, NULL, 'Habiganj', 5, 'হবিগঞ্জ', '24.374945', '91.41553', 'www.habiganj.gov.bd', 1, NULL, NULL),
(39, NULL, 'Sunamganj', 5, 'সুনামগঞ্জ', '25.0658042', '91.3950115', 'www.sunamganj.gov.bd', 1, NULL, NULL),
(40, NULL, 'Narsingdi', 6, 'নরসিংদী', '23.932233', '90.71541', 'www.narsingdi.gov.bd', 1, NULL, NULL),
(41, NULL, 'Gazipur', 6, 'গাজীপুর', '24.0022858', '90.4264283', 'www.gazipur.gov.bd', 1, NULL, NULL),
(42, NULL, 'Shariatpur', 6, 'শরীয়তপুর', NULL, NULL, 'www.shariatpur.gov.bd', 1, NULL, NULL),
(43, NULL, 'Narayanganj', 6, 'নারায়ণগঞ্জ', '23.63366', '90.496482', 'www.narayanganj.gov.bd', 1, NULL, NULL),
(44, NULL, 'Tangail', 6, 'টাঙ্গাইল', NULL, NULL, 'www.tangail.gov.bd', 1, NULL, NULL),
(45, NULL, 'Kishoreganj', 6, 'কিশোরগঞ্জ', '24.444937', '90.776575', 'www.kishoreganj.gov.bd', 1, NULL, NULL),
(46, NULL, 'Manikganj', 6, 'মানিকগঞ্জ', NULL, NULL, 'www.manikganj.gov.bd', 1, NULL, NULL),
(47, NULL, 'Dhaka', 6, 'ঢাকা', '23.7115253', '90.4111451', 'www.dhaka.gov.bd', 1, NULL, NULL),
(48, NULL, 'Munshiganj', 6, 'মুন্সিগঞ্জ', NULL, NULL, 'www.munshiganj.gov.bd', 1, NULL, NULL),
(49, NULL, 'Rajbari', 6, 'রাজবাড়ী', '23.7574305', '89.6444665', 'www.rajbari.gov.bd', 1, NULL, NULL),
(50, NULL, 'Madaripur', 6, 'মাদারীপুর', '23.164102', '90.1896805', 'www.madaripur.gov.bd', 1, NULL, NULL),
(51, NULL, 'Gopalganj', 6, 'গোপালগঞ্জ', '23.0050857', '89.8266059', 'www.gopalganj.gov.bd', 1, NULL, NULL),
(52, NULL, 'Faridpur', 6, 'ফরিদপুর', '23.6070822', '89.8429406', 'www.faridpur.gov.bd', 1, NULL, NULL),
(53, NULL, 'Panchagarh', 7, 'পঞ্চগড়', '26.3411', '88.5541606', 'www.panchagarh.gov.bd', 1, NULL, NULL),
(54, NULL, 'Dinajpur', 7, 'দিনাজপুর', '25.6217061', '88.6354504', 'www.dinajpur.gov.bd', 1, NULL, NULL),
(55, NULL, 'Lalmonirhat', 7, 'লালমনিরহাট', NULL, NULL, 'www.lalmonirhat.gov.bd', 1, NULL, NULL),
(56, NULL, 'Nilphamari', 7, 'নীলফামারী', '25.931794', '88.856006', 'www.nilphamari.gov.bd', 1, NULL, NULL),
(57, NULL, 'Gaibandha', 7, 'গাইবান্ধা', '25.328751', '89.528088', 'www.gaibandha.gov.bd', 1, NULL, NULL),
(58, NULL, 'Thakurgaon', 7, 'ঠাকুরগাঁও', '26.0336945', '88.4616834', 'www.thakurgaon.gov.bd', 1, NULL, NULL),
(59, NULL, 'Rangpur', 7, 'রংপুর', '25.7558096', '89.244462', 'www.rangpur.gov.bd', 1, NULL, NULL),
(60, NULL, 'Kurigram', 7, 'কুড়িগ্রাম', '25.805445', '89.636174', 'www.kurigram.gov.bd', 1, NULL, NULL),
(61, NULL, 'Sherpur', 8, 'শেরপুর', '25.0204933', '90.0152966', 'www.sherpur.gov.bd', 1, NULL, NULL),
(62, NULL, 'Mymensingh', 8, 'ময়মনসিংহ', NULL, NULL, 'www.mymensingh.gov.bd', 1, NULL, NULL),
(63, NULL, 'Jamalpur', 8, 'জামালপুর', '24.937533', '89.937775', 'www.jamalpur.gov.bd', 1, NULL, NULL),
(64, NULL, 'Netrokona', 8, 'নেত্রকোণা', '24.870955', '90.727887', 'www.netrokona.gov.bd', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

DROP TABLE IF EXISTS `divisions`;
CREATE TABLE IF NOT EXISTS `divisions` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`id`, `user_id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Chattagram', 1, NULL, NULL),
(2, NULL, 'Rajshahi', 1, NULL, NULL),
(3, NULL, 'Khulna', 1, NULL, NULL),
(4, NULL, 'Barisal', 1, NULL, NULL),
(5, NULL, 'Sylhet', 1, NULL, NULL),
(6, NULL, 'Dhaka', 1, NULL, NULL),
(7, NULL, 'Rangpur', 1, NULL, NULL),
(8, NULL, 'Mymensingh', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `glossaries`
--

DROP TABLE IF EXISTS `glossaries`;
CREATE TABLE IF NOT EXISTS `glossaries` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `home_pages`
--

DROP TABLE IF EXISTS `home_pages`;
CREATE TABLE IF NOT EXISTS `home_pages` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` longtext COLLATE utf8mb4_unicode_ci,
  `youtube_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `home_pages`
--

INSERT INTO `home_pages` (`id`, `name`, `image`, `details`, `youtube_link`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Name', NULL, 'Details', NULL, 0, '2022-07-27 03:54:24', NULL),
(2, 'Blockchain and Cryptocurrency Education', NULL, NULL, 'https://www.youtube.com/watch?v=xeiWdLYaEpc', 0, '2022-07-27 03:54:24', '2022-07-27 04:30:38');

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

DROP TABLE IF EXISTS `lessons`;
CREATE TABLE IF NOT EXISTS `lessons` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lesson_time` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2021_05_20_183530_create_sessions_table', 1),
(7, '2021_05_20_185532_create_roles_table', 1),
(8, '2022_01_03_201339_create_divisions_table', 1),
(9, '2022_01_03_201518_create_districts_table', 1),
(10, '2022_01_03_201529_create_thanas_table', 1),
(11, '2022_07_19_083759_create_categories_table', 1),
(12, '2022_07_20_045929_create_courses_table', 1),
(13, '2022_07_22_051250_create_lessons_table', 1),
(14, '2022_07_23_172247_create_page_categories_table', 1),
(15, '2022_07_23_174609_create_pages_table', 1),
(16, '2022_07_24_033729_create_site_settings_table', 1),
(17, '2022_07_24_060608_create_questions_table', 1),
(18, '2022_07_25_051316_create_badges_table', 1),
(19, '2022_07_26_063003_create_glossaries_table', 1),
(20, '2022_07_26_104819_create_home_pages_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `page_category_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL,
  `long_description` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `page_categories`
--

DROP TABLE IF EXISTS `page_categories`;
CREATE TABLE IF NOT EXISTS `page_categories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `mark` int(11) NOT NULL,
  `answer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_one` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_two` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_three` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_four` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'super-admin', NULL, NULL),
(2, 'Student', 'student', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('ov5lZ3gtZsJn3320caN1uTsISNFswRDhAK1WLywH', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoicm9rZ0ttVGtUUUZ0Zjd0UXRpOVFucEkwZXBWSHlQemNUenRDUDJUYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9ob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjE3OiJwYXNzd29yZF9oYXNoX3dlYiI7czo2MDoiJDJ5JDEwJHJxc3FneG5VUWhlNnFoeXluR0hiZXVoL1hTRW51NDV2d3FUQkJ4RjJoRGtUa1VQTkpIS29DIjtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyeSQxMCRycXNxZ3huVVFoZTZxaHl5bkdIYmV1aC9YU0VudTQ1dndxVEJCeEYyaERrVGtVUE5KSEtvQyI7fQ==', 1658920860),
('zgXJCsYe0mbclxQKxkd4WWsBk9tvj3rjYMrNpXf0', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoiMElkbDVqYUNmRWg0TzVjMTRxazZIOUhud1RjVG9XUDBDRkNwS29nMSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9ob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjE3OiJwYXNzd29yZF9oYXNoX3dlYiI7czo2MDoiJDJ5JDEwJHJxc3FneG5VUWhlNnFoeXluR0hiZXVoL1hTRW51NDV2d3FUQkJ4RjJoRGtUa1VQTkpIS29DIjtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyeSQxMCRycXNxZ3huVVFoZTZxaHl5bkdIYmV1aC9YU0VudTQ1dndxVEJCeEYyaERrVGtVUE5KSEtvQyI7fQ==', 1658934340);

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
CREATE TABLE IF NOT EXISTS `site_settings` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `copyright` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keyword` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `site_settings`
--

INSERT INTO `site_settings` (`id`, `name`, `email`, `logo`, `favicon`, `meta_image`, `phone`, `copyright`, `meta_title`, `keyword`, `description`, `address`, `icon`, `link`, `created_at`, `updated_at`) VALUES
(1, 'Demo Site Name', 'demo@gmail.com', 'media/logo/logo-62e150d2b5486.png', 'media/logo/favicon-62e150d2c0f52.png', NULL, '01711111111', NULL, NULL, NULL, NULL, 'demo Address', '', '', '2022-07-27 03:54:24', '2022-07-27 08:50:58');

-- --------------------------------------------------------

--
-- Table structure for table `thanas`
--

DROP TABLE IF EXISTS `thanas`;
CREATE TABLE IF NOT EXISTS `thanas` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `division_id` int(11) NOT NULL,
  `district_id` int(11) NOT NULL,
  `bn_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=492 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `thanas`
--

INSERT INTO `thanas` (`id`, `user_id`, `name`, `division_id`, `district_id`, `bn_name`, `url`, `status`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Debidwar', 1, 1, 'দেবিদ্বার', 'debidwar.comilla.gov.bd', 1, NULL, NULL),
(2, NULL, 'Barura', 1, 1, 'বরুড়া', 'barura.comilla.gov.bd', 1, NULL, NULL),
(3, NULL, 'Brahmanpara', 1, 1, 'ব্রাহ্মণপাড়া', 'brahmanpara.comilla.gov.bd', 1, NULL, NULL),
(4, NULL, 'Chandina', 1, 1, 'চান্দিনা', 'chandina.comilla.gov.bd', 1, NULL, NULL),
(5, NULL, 'Chauddagram', 1, 1, 'চৌদ্দগ্রাম', 'chauddagram.comilla.gov.bd', 1, NULL, NULL),
(6, NULL, 'Daudkandi', 1, 1, 'দাউদকান্দি', 'daudkandi.comilla.gov.bd', 1, NULL, NULL),
(7, NULL, 'Homna', 1, 1, 'হোমনা', 'homna.comilla.gov.bd', 1, NULL, NULL),
(8, NULL, 'Laksam', 1, 1, 'লাকসাম', 'laksam.comilla.gov.bd', 1, NULL, NULL),
(9, NULL, 'Muradnagar', 1, 1, 'মুরাদনগর', 'muradnagar.comilla.gov.bd', 1, NULL, NULL),
(10, NULL, 'Nangalkot', 1, 1, 'নাঙ্গলকোট', 'nangalkot.comilla.gov.bd', 1, NULL, NULL),
(11, NULL, 'Comilla Sadar', 1, 1, 'কুমিল্লা সদর', 'comillasadar.comilla.gov.bd', 1, NULL, NULL),
(12, NULL, 'Meghna', 1, 1, 'মেঘনা', 'meghna.comilla.gov.bd', 1, NULL, NULL),
(13, NULL, 'Monohargonj', 1, 1, 'মনোহরগঞ্জ', 'monohargonj.comilla.gov.bd', 1, NULL, NULL),
(14, NULL, 'Sadarsouth', 1, 1, 'সদর দক্ষিণ', 'sadarsouth.comilla.gov.bd', 1, NULL, NULL),
(15, NULL, 'Titas', 1, 1, 'তিতাস', 'titas.comilla.gov.bd', 1, NULL, NULL),
(16, NULL, 'Burichang', 1, 1, 'বুড়িচং', 'burichang.comilla.gov.bd', 1, NULL, NULL),
(17, NULL, 'Lalmai', 1, 1, 'লালমাই', 'lalmai.comilla.gov.bd', 1, NULL, NULL),
(18, NULL, 'Chhagalnaiya', 1, 2, 'ছাগলনাইয়া', 'chhagalnaiya.feni.gov.bd', 1, NULL, NULL),
(19, NULL, 'Feni Sadar', 1, 2, 'ফেনী সদর', 'sadar.feni.gov.bd', 1, NULL, NULL),
(20, NULL, 'Sonagazi', 1, 2, 'সোনাগাজী', 'sonagazi.feni.gov.bd', 1, NULL, NULL),
(21, NULL, 'Fulgazi', 1, 2, 'ফুলগাজী', 'fulgazi.feni.gov.bd', 1, NULL, NULL),
(22, NULL, 'Parshuram', 1, 2, 'পরশুরাম', 'parshuram.feni.gov.bd', 1, NULL, NULL),
(23, NULL, 'Daganbhuiyan', 1, 2, 'দাগনভূঞা', 'daganbhuiyan.feni.gov.bd', 1, NULL, NULL),
(24, NULL, 'Brahmanbaria Sadar', 1, 3, 'ব্রাহ্মণবাড়িয়া সদর', 'sadar.brahmanbaria.gov.bd', 1, NULL, NULL),
(25, NULL, 'Kasba', 1, 3, 'কসবা', 'kasba.brahmanbaria.gov.bd', 1, NULL, NULL),
(26, NULL, 'Nasirnagar', 1, 3, 'নাসিরনগর', 'nasirnagar.brahmanbaria.gov.bd', 1, NULL, NULL),
(27, NULL, 'Sarail', 1, 3, 'সরাইল', 'sarail.brahmanbaria.gov.bd', 1, NULL, NULL),
(28, NULL, 'Ashuganj', 1, 3, 'আশুগঞ্জ', 'ashuganj.brahmanbaria.gov.bd', 1, NULL, NULL),
(29, NULL, 'Akhaura', 1, 3, 'আখাউড়া', 'akhaura.brahmanbaria.gov.bd', 1, NULL, NULL),
(30, NULL, 'Nabinagar', 1, 3, 'নবীনগর', 'nabinagar.brahmanbaria.gov.bd', 1, NULL, NULL),
(31, NULL, 'Bancharampur', 1, 3, 'বাঞ্ছারামপুর', 'bancharampur.brahmanbaria.gov.bd', 1, NULL, NULL),
(32, NULL, 'Bijoynagar', 1, 3, 'বিজয়নগর', 'bijoynagar.brahmanbaria.gov.bd    ', 1, NULL, NULL),
(33, NULL, 'Rangamati Sadar', 1, 3, 'রাঙ্গামাটি সদর', 'sadar.rangamati.gov.bd', 1, NULL, NULL),
(34, NULL, 'Kaptai', 1, 3, 'কাপ্তাই', 'kaptai.rangamati.gov.bd', 1, NULL, NULL),
(35, NULL, 'Kawkhali', 1, 3, 'কাউখালী', 'kawkhali.rangamati.gov.bd', 1, NULL, NULL),
(36, NULL, 'Baghaichari', 1, 3, 'বাঘাইছড়ি', 'baghaichari.rangamati.gov.bd', 1, NULL, NULL),
(37, NULL, 'Barkal', 1, 3, 'বরকল', 'barkal.rangamati.gov.bd', 1, NULL, NULL),
(38, NULL, 'Langadu', 1, 3, 'লংগদু', 'langadu.rangamati.gov.bd', 1, NULL, NULL),
(39, NULL, 'Rajasthali', 1, 3, 'রাজস্থলী', 'rajasthali.rangamati.gov.bd', 1, NULL, NULL),
(40, NULL, 'Belaichari', 1, 3, 'বিলাইছড়ি', 'belaichari.rangamati.gov.bd', 1, NULL, NULL),
(41, NULL, 'Juraichari', 1, 3, 'জুরাছড়ি', 'juraichari.rangamati.gov.bd', 1, NULL, NULL),
(42, NULL, 'Naniarchar', 1, 3, 'নানিয়ারচর', 'naniarchar.rangamati.gov.bd', 1, NULL, NULL),
(43, NULL, 'Noakhali Sadar', 1, 5, 'নোয়াখালী সদর', 'sadar.noakhali.gov.bd', 1, NULL, NULL),
(44, NULL, 'Companiganj', 1, 5, 'কোম্পানীগঞ্জ', 'companiganj.noakhali.gov.bd', 1, NULL, NULL),
(45, NULL, 'Begumganj', 1, 5, 'বেগমগঞ্জ', 'begumganj.noakhali.gov.bd', 1, NULL, NULL),
(46, NULL, 'Hatia', 1, 5, 'হাতিয়া', 'hatia.noakhali.gov.bd', 1, NULL, NULL),
(47, NULL, 'Subarnachar', 1, 5, 'সুবর্ণচর', 'subarnachar.noakhali.gov.bd', 1, NULL, NULL),
(48, NULL, 'Kabirhat', 1, 5, 'কবিরহাট', 'kabirhat.noakhali.gov.bd', 1, NULL, NULL),
(49, NULL, 'Senbug', 1, 5, 'সেনবাগ', 'senbug.noakhali.gov.bd', 1, NULL, NULL),
(50, NULL, 'Chatkhil', 1, 5, 'চাটখিল', 'chatkhil.noakhali.gov.bd', 1, NULL, NULL),
(51, NULL, 'Sonaimori', 1, 5, 'সোনাইমুড়ী', 'sonaimori.noakhali.gov.bd', 1, NULL, NULL),
(52, NULL, 'Haimchar', 1, 6, 'হাইমচর', 'haimchar.chandpur.gov.bd', 1, NULL, NULL),
(53, NULL, 'Kachua', 1, 6, 'কচুয়া', 'kachua.chandpur.gov.bd', 1, NULL, NULL),
(54, NULL, 'Shahrasti', 1, 6, 'শাহরাস্তি	', 'shahrasti.chandpur.gov.bd', 1, NULL, NULL),
(55, NULL, 'Chandpur Sadar', 1, 6, 'চাঁদপুর সদর', 'sadar.chandpur.gov.bd', 1, NULL, NULL),
(56, NULL, 'Matlab South', 1, 6, 'মতলব দক্ষিণ', 'matlabsouth.chandpur.gov.bd', 1, NULL, NULL),
(57, NULL, 'Hajiganj', 1, 6, 'হাজীগঞ্জ', 'hajiganj.chandpur.gov.bd', 1, NULL, NULL),
(58, NULL, 'Matlab North', 1, 6, 'মতলব উত্তর', 'matlabnorth.chandpur.gov.bd', 1, NULL, NULL),
(59, NULL, 'Faridgonj', 1, 6, 'ফরিদগঞ্জ', 'faridgonj.chandpur.gov.bd', 1, NULL, NULL),
(60, NULL, 'Lakshmipur Sadar', 1, 7, 'লক্ষ্মীপুর সদর', 'sadar.lakshmipur.gov.bd', 1, NULL, NULL),
(61, NULL, 'Kamalnagar', 1, 7, 'কমলনগর', 'kamalnagar.lakshmipur.gov.bd', 1, NULL, NULL),
(62, NULL, 'Raipur', 1, 7, 'রায়পুর', 'raipur.lakshmipur.gov.bd', 1, NULL, NULL),
(63, NULL, 'Ramgati', 1, 7, 'রামগতি', 'ramgati.lakshmipur.gov.bd', 1, NULL, NULL),
(64, NULL, 'Ramganj', 1, 7, 'রামগঞ্জ', 'ramganj.lakshmipur.gov.bd', 1, NULL, NULL),
(65, NULL, 'Rangunia', 1, 8, 'রাঙ্গুনিয়া', 'rangunia.chittagong.gov.bd', 1, NULL, NULL),
(66, NULL, 'Sitakunda', 1, 8, 'সীতাকুন্ড', 'sitakunda.chittagong.gov.bd', 1, NULL, NULL),
(67, NULL, 'Mirsharai', 1, 8, 'মীরসরাই', 'mirsharai.chittagong.gov.bd', 1, NULL, NULL),
(68, NULL, 'Patiya', 1, 8, 'পটিয়া', 'patiya.chittagong.gov.bd', 1, NULL, NULL),
(69, NULL, 'Sandwip', 1, 8, 'সন্দ্বীপ', 'sandwip.chittagong.gov.bd', 1, NULL, NULL),
(70, NULL, 'Banshkhali', 1, 8, 'বাঁশখালী', 'banshkhali.chittagong.gov.bd', 1, NULL, NULL),
(71, NULL, 'Boalkhali', 1, 8, 'বোয়ালখালী', 'boalkhali.chittagong.gov.bd', 1, NULL, NULL),
(72, NULL, 'Anwara', 1, 8, 'আনোয়ারা', 'anwara.chittagong.gov.bd', 1, NULL, NULL),
(73, NULL, 'Chandanaish', 1, 8, 'চন্দনাইশ', 'chandanaish.chittagong.gov.bd', 1, NULL, NULL),
(74, NULL, 'Satkania', 1, 8, 'সাতকানিয়া', 'satkania.chittagong.gov.bd', 1, NULL, NULL),
(75, NULL, 'Lohagara', 1, 8, 'লোহাগাড়া', 'lohagara.chittagong.gov.bd', 1, NULL, NULL),
(76, NULL, 'Hathazari', 1, 8, 'হাটহাজারী', 'hathazari.chittagong.gov.bd', 1, NULL, NULL),
(77, NULL, 'Fatikchhari', 1, 8, 'ফটিকছড়ি', 'fatikchhari.chittagong.gov.bd', 1, NULL, NULL),
(78, NULL, 'Raozan', 1, 8, 'রাউজান', 'raozan.chittagong.gov.bd', 1, NULL, NULL),
(79, NULL, 'Karnafuli', 1, 8, 'কর্ণফুলী', 'karnafuli.chittagong.gov.bd', 1, NULL, NULL),
(80, NULL, 'Coxsbazar Sadar', 1, 9, 'কক্সবাজার সদর', 'sadar.coxsbazar.gov.bd', 1, NULL, NULL),
(81, NULL, 'Chakaria', 1, 9, 'চকরিয়া', 'chakaria.coxsbazar.gov.bd', 1, NULL, NULL),
(82, NULL, 'Kutubdia', 1, 9, 'কুতুবদিয়া', 'kutubdia.coxsbazar.gov.bd', 1, NULL, NULL),
(83, NULL, 'Ukhiya', 1, 9, 'উখিয়া', 'ukhiya.coxsbazar.gov.bd', 1, NULL, NULL),
(84, NULL, 'Moheshkhali', 1, 9, 'মহেশখালী', 'moheshkhali.coxsbazar.gov.bd', 1, NULL, NULL),
(85, NULL, 'Pekua', 1, 9, 'পেকুয়া', 'pekua.coxsbazar.gov.bd', 1, NULL, NULL),
(86, NULL, 'Ramu', 1, 9, 'রামু', 'ramu.coxsbazar.gov.bd', 1, NULL, NULL),
(87, NULL, 'Teknaf', 1, 9, 'টেকনাফ', 'teknaf.coxsbazar.gov.bd', 1, NULL, NULL),
(88, NULL, 'Khagrachhari Sadar', 1, 10, 'খাগড়াছড়ি সদর', 'sadar.khagrachhari.gov.bd', 1, NULL, NULL),
(89, NULL, 'Dighinala', 1, 10, 'দিঘীনালা', 'dighinala.khagrachhari.gov.bd', 1, NULL, NULL),
(90, NULL, 'Panchari', 1, 10, 'পানছড়ি', 'panchari.khagrachhari.gov.bd', 1, NULL, NULL),
(91, NULL, 'Laxmichhari', 1, 10, 'লক্ষীছড়ি', 'laxmichhari.khagrachhari.gov.bd', 1, NULL, NULL),
(92, NULL, 'Mohalchari', 1, 10, 'মহালছড়ি', 'mohalchari.khagrachhari.gov.bd', 1, NULL, NULL),
(93, NULL, 'Manikchari', 1, 10, 'মানিকছড়ি', 'manikchari.khagrachhari.gov.bd', 1, NULL, NULL),
(94, NULL, 'Ramgarh', 1, 10, 'রামগড়', 'ramgarh.khagrachhari.gov.bd', 1, NULL, NULL),
(95, NULL, 'Matiranga', 1, 10, 'মাটিরাঙ্গা', 'matiranga.khagrachhari.gov.bd', 1, NULL, NULL),
(96, NULL, 'Guimara', 1, 10, 'গুইমারা', 'guimara.khagrachhari.gov.bd', 1, NULL, NULL),
(97, NULL, 'Bandarban Sadar', 1, 11, 'বান্দরবান সদর', 'sadar.bandarban.gov.bd', 1, NULL, NULL),
(98, NULL, 'Alikadam', 1, 11, 'আলীকদম', 'alikadam.bandarban.gov.bd', 1, NULL, NULL),
(99, NULL, 'Naikhongchhari', 1, 11, 'নাইক্ষ্যংছড়ি', 'naikhongchhari.bandarban.gov.bd', 1, NULL, NULL),
(100, NULL, 'Rowangchhari', 1, 11, 'রোয়াংছড়ি', 'rowangchhari.bandarban.gov.bd', 1, NULL, NULL),
(101, NULL, 'Lama', 1, 11, 'লামা', 'lama.bandarban.gov.bd', 1, NULL, NULL),
(102, NULL, 'Ruma', 1, 11, 'রুমা', 'ruma.bandarban.gov.bd', 1, NULL, NULL),
(103, NULL, 'Thanchi', 1, 11, 'থানচি', 'thanchi.bandarban.gov.bd', 1, NULL, NULL),
(104, NULL, 'Belkuchi', 2, 12, 'বেলকুচি', 'belkuchi.sirajganj.gov.bd', 1, NULL, NULL),
(105, NULL, 'Chauhali', 2, 12, 'চৌহালি', 'chauhali.sirajganj.gov.bd', 1, NULL, NULL),
(106, NULL, 'Kamarkhand', 2, 12, 'কামারখন্দ', 'kamarkhand.sirajganj.gov.bd', 1, NULL, NULL),
(107, NULL, 'Kazipur', 2, 12, 'কাজীপুর', 'kazipur.sirajganj.gov.bd', 1, NULL, NULL),
(108, NULL, 'Raigonj', 2, 12, 'রায়গঞ্জ', 'raigonj.sirajganj.gov.bd', 1, NULL, NULL),
(109, NULL, 'Shahjadpur', 2, 12, 'শাহজাদপুর', 'shahjadpur.sirajganj.gov.bd', 1, NULL, NULL),
(110, NULL, 'Sirajganj Sadar', 2, 12, 'সিরাজগঞ্জ সদর', 'sirajganjsadar.sirajganj.gov.bd', 1, NULL, NULL),
(111, NULL, 'Tarash', 2, 12, 'তাড়াশ', 'tarash.sirajganj.gov.bd', 1, NULL, NULL),
(112, NULL, 'Ullapara', 2, 12, 'উল্লাপাড়া', 'ullapara.sirajganj.gov.bd', 1, NULL, NULL),
(113, NULL, 'Sujanagar', 2, 13, 'সুজানগর', 'sujanagar.pabna.gov.bd', 1, NULL, NULL),
(114, NULL, 'Ishurdi', 2, 13, 'ঈশ্বরদী', 'ishurdi.pabna.gov.bd', 1, NULL, NULL),
(115, NULL, 'Bhangura', 2, 13, 'ভাঙ্গুড়া', 'bhangura.pabna.gov.bd', 1, NULL, NULL),
(116, NULL, 'Pabna Sadar', 2, 13, 'পাবনা সদর', 'pabnasadar.pabna.gov.bd', 1, NULL, NULL),
(117, NULL, 'Bera', 2, 13, 'বেড়া', 'bera.pabna.gov.bd', 1, NULL, NULL),
(118, NULL, 'Atghoria', 2, 13, 'আটঘরিয়া', 'atghoria.pabna.gov.bd', 1, NULL, NULL),
(119, NULL, 'Chatmohar', 2, 13, 'চাটমোহর', 'chatmohar.pabna.gov.bd', 1, NULL, NULL),
(120, NULL, 'Santhia', 2, 13, 'সাঁথিয়া', 'santhia.pabna.gov.bd', 1, NULL, NULL),
(121, NULL, 'Faridpur', 2, 13, 'ফরিদপুর', 'faridpur.pabna.gov.bd', 1, NULL, NULL),
(122, NULL, 'Kahaloo', 2, 14, 'কাহালু', 'kahaloo.bogra.gov.bd', 1, NULL, NULL),
(123, NULL, 'Bogra Sadar', 2, 14, 'বগুড়া সদর', 'sadar.bogra.gov.bd', 1, NULL, NULL),
(124, NULL, 'Shariakandi', 2, 14, 'সারিয়াকান্দি', 'shariakandi.bogra.gov.bd', 1, NULL, NULL),
(125, NULL, 'Shajahanpur', 2, 14, 'শাজাহানপুর', 'shajahanpur.bogra.gov.bd', 1, NULL, NULL),
(126, NULL, 'Dupchanchia', 2, 14, 'দুপচাচিঁয়া', 'dupchanchia.bogra.gov.bd', 1, NULL, NULL),
(127, NULL, 'Adamdighi', 2, 14, 'আদমদিঘি', 'adamdighi.bogra.gov.bd', 1, NULL, NULL),
(128, NULL, 'Nondigram', 2, 14, 'নন্দিগ্রাম', 'nondigram.bogra.gov.bd', 1, NULL, NULL),
(129, NULL, 'Sonatala', 2, 14, 'সোনাতলা', 'sonatala.bogra.gov.bd', 1, NULL, NULL),
(130, NULL, 'Dhunot', 2, 14, 'ধুনট', 'dhunot.bogra.gov.bd', 1, NULL, NULL),
(131, NULL, 'Gabtali', 2, 14, 'গাবতলী', 'gabtali.bogra.gov.bd', 1, NULL, NULL),
(132, NULL, 'Sherpur', 2, 14, 'শেরপুর', 'sherpur.bogra.gov.bd', 1, NULL, NULL),
(133, NULL, 'Shibganj', 2, 14, 'শিবগঞ্জ', 'shibganj.bogra.gov.bd', 1, NULL, NULL),
(134, NULL, 'Paba', 2, 15, 'পবা', 'paba.rajshahi.gov.bd', 1, NULL, NULL),
(135, NULL, 'Durgapur', 2, 15, 'দুর্গাপুর', 'durgapur.rajshahi.gov.bd', 1, NULL, NULL),
(136, NULL, 'Mohonpur', 2, 15, 'মোহনপুর', 'mohonpur.rajshahi.gov.bd', 1, NULL, NULL),
(137, NULL, 'Charghat', 2, 15, 'চারঘাট', 'charghat.rajshahi.gov.bd', 1, NULL, NULL),
(138, NULL, 'Puthia', 2, 15, 'পুঠিয়া', 'puthia.rajshahi.gov.bd', 1, NULL, NULL),
(139, NULL, 'Bagha', 2, 15, 'বাঘা', 'bagha.rajshahi.gov.bd', 1, NULL, NULL),
(140, NULL, 'Godagari', 2, 15, 'গোদাগাড়ী', 'godagari.rajshahi.gov.bd', 1, NULL, NULL),
(141, NULL, 'Tanore', 2, 15, 'তানোর', 'tanore.rajshahi.gov.bd', 1, NULL, NULL),
(142, NULL, 'Bagmara', 2, 15, 'বাগমারা', 'bagmara.rajshahi.gov.bd', 1, NULL, NULL),
(143, NULL, 'Natore Sadar', 2, 16, 'নাটোর সদর', 'natoresadar.natore.gov.bd', 1, NULL, NULL),
(144, NULL, 'Singra', 2, 16, 'সিংড়া', 'singra.natore.gov.bd', 1, NULL, NULL),
(145, NULL, 'Baraigram', 2, 16, 'বড়াইগ্রাম', 'baraigram.natore.gov.bd', 1, NULL, NULL),
(146, NULL, 'Bagatipara', 2, 16, 'বাগাতিপাড়া', 'bagatipara.natore.gov.bd', 1, NULL, NULL),
(147, NULL, 'Lalpur', 2, 16, 'লালপুর', 'lalpur.natore.gov.bd', 1, NULL, NULL),
(148, NULL, 'Gurudaspur', 2, 16, 'গুরুদাসপুর', 'gurudaspur.natore.gov.bd', 1, NULL, NULL),
(149, NULL, 'Naldanga', 2, 16, 'নলডাঙ্গা', 'naldanga.natore.gov.bd', 1, NULL, NULL),
(150, NULL, 'Akkelpur', 2, 17, 'আক্কেলপুর', 'akkelpur.joypurhat.gov.bd', 1, NULL, NULL),
(151, NULL, 'Kalai', 2, 17, 'কালাই', 'kalai.joypurhat.gov.bd', 1, NULL, NULL),
(152, NULL, 'Khetlal', 2, 17, 'ক্ষেতলাল', 'khetlal.joypurhat.gov.bd', 1, NULL, NULL),
(153, NULL, 'Panchbibi', 2, 17, 'পাঁচবিবি', 'panchbibi.joypurhat.gov.bd', 1, NULL, NULL),
(154, NULL, 'Joypurhat Sadar', 2, 17, 'জয়পুরহাট সদর', 'joypurhatsadar.joypurhat.gov.bd', 1, NULL, NULL),
(155, NULL, 'Chapainawabganj Sadar', 2, 18, 'চাঁপাইনবাবগঞ্জ সদর', 'chapainawabganjsadar.chapainawabganj.gov.bd', 1, NULL, NULL),
(156, NULL, 'Gomostapur', 2, 18, 'গোমস্তাপুর', 'gomostapur.chapainawabganj.gov.bd', 1, NULL, NULL),
(157, NULL, 'Nachol', 2, 18, 'নাচোল', 'nachol.chapainawabganj.gov.bd', 1, NULL, NULL),
(158, NULL, 'Bholahat', 2, 18, 'ভোলাহাট', 'bholahat.chapainawabganj.gov.bd', 1, NULL, NULL),
(159, NULL, 'Shibganj', 2, 18, 'শিবগঞ্জ', 'shibganj.chapainawabganj.gov.bd', 1, NULL, NULL),
(160, NULL, 'Mohadevpur', 2, 19, 'মহাদেবপুর', 'mohadevpur.naogaon.gov.bd', 1, NULL, NULL),
(161, NULL, 'Badalgachi', 2, 19, 'বদলগাছী', 'badalgachi.naogaon.gov.bd', 1, NULL, NULL),
(162, NULL, 'Patnitala', 2, 19, 'পত্নিতলা', 'patnitala.naogaon.gov.bd', 1, NULL, NULL),
(163, NULL, 'Dhamoirhat', 2, 19, 'ধামইরহাট', 'dhamoirhat.naogaon.gov.bd', 1, NULL, NULL),
(164, NULL, 'Niamatpur', 2, 19, 'নিয়ামতপুর', 'niamatpur.naogaon.gov.bd', 1, NULL, NULL),
(165, NULL, 'Manda', 2, 19, 'মান্দা', 'manda.naogaon.gov.bd', 1, NULL, NULL),
(166, NULL, 'Atrai', 2, 19, 'আত্রাই', 'atrai.naogaon.gov.bd', 1, NULL, NULL),
(167, NULL, 'Raninagar', 2, 19, 'রাণীনগর', 'raninagar.naogaon.gov.bd', 1, NULL, NULL),
(168, NULL, 'Naogaon Sadar', 2, 19, 'নওগাঁ সদর', 'naogaonsadar.naogaon.gov.bd', 1, NULL, NULL),
(169, NULL, 'Porsha', 2, 19, 'পোরশা', 'porsha.naogaon.gov.bd', 1, NULL, NULL),
(170, NULL, 'Sapahar', 2, 19, 'সাপাহার', 'sapahar.naogaon.gov.bd', 1, NULL, NULL),
(171, NULL, 'Manirampur', 3, 20, 'মণিরামপুর', 'manirampur.jessore.gov.bd', 1, NULL, NULL),
(172, NULL, 'Abhaynagar', 3, 20, 'অভয়নগর', 'abhaynagar.jessore.gov.bd', 1, NULL, NULL),
(173, NULL, 'Bagherpara', 3, 20, 'বাঘারপাড়া', 'bagherpara.jessore.gov.bd', 1, NULL, NULL),
(174, NULL, 'Chougachha', 3, 20, 'চৌগাছা', 'chougachha.jessore.gov.bd', 1, NULL, NULL),
(175, NULL, 'Jhikargacha', 3, 20, 'ঝিকরগাছা', 'jhikargacha.jessore.gov.bd', 1, NULL, NULL),
(176, NULL, 'Keshabpur', 3, 20, 'কেশবপুর', 'keshabpur.jessore.gov.bd', 1, NULL, NULL),
(177, NULL, 'Jessore Sadar', 3, 20, 'যশোর সদর', 'sadar.jessore.gov.bd', 1, NULL, NULL),
(178, NULL, 'Sharsha', 3, 20, 'শার্শা', 'sharsha.jessore.gov.bd', 1, NULL, NULL),
(179, NULL, 'Assasuni', 3, 21, 'আশাশুনি', 'assasuni.satkhira.gov.bd', 1, NULL, NULL),
(180, NULL, 'Debhata', 3, 21, 'দেবহাটা', 'debhata.satkhira.gov.bd', 1, NULL, NULL),
(181, NULL, 'Kalaroa', 3, 21, 'কলারোয়া', 'kalaroa.satkhira.gov.bd', 1, NULL, NULL),
(182, NULL, 'Satkhira Sadar', 3, 21, 'সাতক্ষীরা সদর', 'satkhirasadar.satkhira.gov.bd', 1, NULL, NULL),
(183, NULL, 'Shyamnagar', 3, 21, 'শ্যামনগর', 'shyamnagar.satkhira.gov.bd', 1, NULL, NULL),
(184, NULL, 'Tala', 3, 21, 'তালা', 'tala.satkhira.gov.bd', 1, NULL, NULL),
(185, NULL, 'Kaliganj', 3, 21, 'কালিগঞ্জ', 'kaliganj.satkhira.gov.bd', 1, NULL, NULL),
(186, NULL, 'Mujibnagar', 3, 22, 'মুজিবনগর', 'mujibnagar.meherpur.gov.bd', 1, NULL, NULL),
(187, NULL, 'Meherpur Sadar', 3, 22, 'মেহেরপুর সদর', 'meherpursadar.meherpur.gov.bd', 1, NULL, NULL),
(188, NULL, 'Gangni', 3, 22, 'গাংনী', 'gangni.meherpur.gov.bd', 1, NULL, NULL),
(189, NULL, 'Narail Sadar', 3, 23, 'নড়াইল সদর', 'narailsadar.narail.gov.bd', 1, NULL, NULL),
(190, NULL, 'Lohagara', 3, 23, 'লোহাগড়া', 'lohagara.narail.gov.bd', 1, NULL, NULL),
(191, NULL, 'Kalia', 3, 23, 'কালিয়া', 'kalia.narail.gov.bd', 1, NULL, NULL),
(192, NULL, 'Chuadanga Sadar', 3, 24, 'চুয়াডাঙ্গা সদর', 'chuadangasadar.chuadanga.gov.bd', 1, NULL, NULL),
(193, NULL, 'Alamdanga', 3, 24, 'আলমডাঙ্গা', 'alamdanga.chuadanga.gov.bd', 1, NULL, NULL),
(194, NULL, 'Damurhuda', 3, 24, 'দামুড়হুদা', 'damurhuda.chuadanga.gov.bd', 1, NULL, NULL),
(195, NULL, 'Jibannagar', 3, 24, 'জীবননগর', 'jibannagar.chuadanga.gov.bd', 1, NULL, NULL),
(196, NULL, 'Kushtia Sadar', 3, 25, 'কুষ্টিয়া সদর', 'kushtiasadar.kushtia.gov.bd', 1, NULL, NULL),
(197, NULL, 'Kumarkhali', 3, 25, 'কুমারখালী', 'kumarkhali.kushtia.gov.bd', 1, NULL, NULL),
(198, NULL, 'Khoksa', 3, 25, 'খোকসা', 'khoksa.kushtia.gov.bd', 1, NULL, NULL),
(199, NULL, 'Mirpur', 3, 25, 'মিরপুর', 'mirpurkushtia.kushtia.gov.bd', 1, NULL, NULL),
(200, NULL, 'Daulatpur', 3, 25, 'দৌলতপুর', 'daulatpur.kushtia.gov.bd', 1, NULL, NULL),
(201, NULL, 'Bheramara', 3, 25, 'ভেড়ামারা', 'bheramara.kushtia.gov.bd', 1, NULL, NULL),
(202, NULL, 'Shalikha', 3, 26, 'শালিখা', 'shalikha.magura.gov.bd', 1, NULL, NULL),
(203, NULL, 'Sreepur', 3, 26, 'শ্রীপুর', 'sreepur.magura.gov.bd', 1, NULL, NULL),
(204, NULL, 'Magura Sadar', 3, 26, 'মাগুরা সদর', 'magurasadar.magura.gov.bd', 1, NULL, NULL),
(205, NULL, 'Mohammadpur', 3, 26, 'মহম্মদপুর', 'mohammadpur.magura.gov.bd', 1, NULL, NULL),
(206, NULL, 'Paikgasa', 3, 27, 'পাইকগাছা', 'paikgasa.khulna.gov.bd', 1, NULL, NULL),
(207, NULL, 'Fultola', 3, 27, 'ফুলতলা', 'fultola.khulna.gov.bd', 1, NULL, NULL),
(208, NULL, 'Digholia', 3, 27, 'দিঘলিয়া', 'digholia.khulna.gov.bd', 1, NULL, NULL),
(209, NULL, 'Rupsha', 3, 27, 'রূপসা', 'rupsha.khulna.gov.bd', 1, NULL, NULL),
(210, NULL, 'Terokhada', 3, 27, 'তেরখাদা', 'terokhada.khulna.gov.bd', 1, NULL, NULL),
(211, NULL, 'Dumuria', 3, 27, 'ডুমুরিয়া', 'dumuria.khulna.gov.bd', 1, NULL, NULL),
(212, NULL, 'Botiaghata', 3, 27, 'বটিয়াঘাটা', 'botiaghata.khulna.gov.bd', 1, NULL, NULL),
(213, NULL, 'Dakop', 3, 27, 'দাকোপ', 'dakop.khulna.gov.bd', 1, NULL, NULL),
(214, NULL, 'Koyra', 3, 27, 'কয়রা', 'koyra.khulna.gov.bd', 1, NULL, NULL),
(215, NULL, 'Fakirhat', 3, 28, 'ফকিরহাট', 'fakirhat.bagerhat.gov.bd', 1, NULL, NULL),
(216, NULL, 'Bagerhat Sadar', 3, 28, 'বাগেরহাট সদর', 'sadar.bagerhat.gov.bd', 1, NULL, NULL),
(217, NULL, 'Mollahat', 3, 28, 'মোল্লাহাট', 'mollahat.bagerhat.gov.bd', 1, NULL, NULL),
(218, NULL, 'Sarankhola', 3, 28, 'শরণখোলা', 'sarankhola.bagerhat.gov.bd', 1, NULL, NULL),
(219, NULL, 'Rampal', 3, 28, 'রামপাল', 'rampal.bagerhat.gov.bd', 1, NULL, NULL),
(220, NULL, 'Morrelganj', 3, 28, 'মোড়েলগঞ্জ', 'morrelganj.bagerhat.gov.bd', 1, NULL, NULL),
(221, NULL, 'Kachua', 3, 28, 'কচুয়া', 'kachua.bagerhat.gov.bd', 1, NULL, NULL),
(222, NULL, 'Mongla', 3, 28, 'মোংলা', 'mongla.bagerhat.gov.bd', 1, NULL, NULL),
(223, NULL, 'Chitalmari', 3, 28, 'চিতলমারী', 'chitalmari.bagerhat.gov.bd', 1, NULL, NULL),
(224, NULL, 'Jhenaidah Sadar', 3, 29, 'ঝিনাইদহ সদর', 'sadar.jhenaidah.gov.bd', 1, NULL, NULL),
(225, NULL, 'Shailkupa', 3, 29, 'শৈলকুপা', 'shailkupa.jhenaidah.gov.bd', 1, NULL, NULL),
(226, NULL, 'Harinakundu', 3, 29, 'হরিণাকুন্ডু', 'harinakundu.jhenaidah.gov.bd', 1, NULL, NULL),
(227, NULL, 'Kaliganj', 3, 29, 'কালীগঞ্জ', 'kaliganj.jhenaidah.gov.bd', 1, NULL, NULL),
(228, NULL, 'Kotchandpur', 3, 29, 'কোটচাঁদপুর', 'kotchandpur.jhenaidah.gov.bd', 1, NULL, NULL),
(229, NULL, 'Moheshpur', 3, 29, 'মহেশপুর', 'moheshpur.jhenaidah.gov.bd', 1, NULL, NULL),
(230, NULL, 'Jhalakathi Sadar', 4, 30, 'ঝালকাঠি সদর', 'sadar.jhalakathi.gov.bd', 1, NULL, NULL),
(231, NULL, 'Kathalia', 4, 30, 'কাঠালিয়া', 'kathalia.jhalakathi.gov.bd', 1, NULL, NULL),
(232, NULL, 'Nalchity', 4, 30, 'নলছিটি', 'nalchity.jhalakathi.gov.bd', 1, NULL, NULL),
(233, NULL, 'Rajapur', 4, 30, 'রাজাপুর', 'rajapur.jhalakathi.gov.bd', 1, NULL, NULL),
(234, NULL, 'Bauphal', 4, 31, 'বাউফল', 'bauphal.patuakhali.gov.bd', 1, NULL, NULL),
(235, NULL, 'Patuakhali Sadar', 4, 31, 'পটুয়াখালী সদর', 'sadar.patuakhali.gov.bd', 1, NULL, NULL),
(236, NULL, 'Dumki', 4, 31, 'দুমকি', 'dumki.patuakhali.gov.bd', 1, NULL, NULL),
(237, NULL, 'Dashmina', 4, 31, 'দশমিনা', 'dashmina.patuakhali.gov.bd', 1, NULL, NULL),
(238, NULL, 'Kalapara', 4, 31, 'কলাপাড়া', 'kalapara.patuakhali.gov.bd', 1, NULL, NULL),
(239, NULL, 'Mirzaganj', 4, 31, 'মির্জাগঞ্জ', 'mirzaganj.patuakhali.gov.bd', 1, NULL, NULL),
(240, NULL, 'Galachipa', 4, 31, 'গলাচিপা', 'galachipa.patuakhali.gov.bd', 1, NULL, NULL),
(241, NULL, 'Rangabali', 4, 31, 'রাঙ্গাবালী', 'rangabali.patuakhali.gov.bd', 1, NULL, NULL),
(242, NULL, 'Pirojpur Sadar', 4, 32, 'পিরোজপুর সদর', 'sadar.pirojpur.gov.bd', 1, NULL, NULL),
(243, NULL, 'Nazirpur', 4, 32, 'নাজিরপুর', 'nazirpur.pirojpur.gov.bd', 1, NULL, NULL),
(244, NULL, 'Kawkhali', 4, 32, 'কাউখালী', 'kawkhali.pirojpur.gov.bd', 1, NULL, NULL),
(245, NULL, 'Zianagar', 4, 32, 'জিয়ানগর', 'zianagar.pirojpur.gov.bd', 1, NULL, NULL),
(246, NULL, 'Bhandaria', 4, 32, 'ভান্ডারিয়া', 'bhandaria.pirojpur.gov.bd', 1, NULL, NULL),
(247, NULL, 'Mathbaria', 4, 32, 'মঠবাড়ীয়া', 'mathbaria.pirojpur.gov.bd', 1, NULL, NULL),
(248, NULL, 'Nesarabad', 4, 32, 'নেছারাবাদ', 'nesarabad.pirojpur.gov.bd', 1, NULL, NULL),
(249, NULL, 'Barisal Sadar', 4, 33, 'বরিশাল সদর', 'barisalsadar.barisal.gov.bd', 1, NULL, NULL),
(250, NULL, 'Bakerganj', 4, 33, 'বাকেরগঞ্জ', 'bakerganj.barisal.gov.bd', 1, NULL, NULL),
(251, NULL, 'Babuganj', 4, 33, 'বাবুগঞ্জ', 'babuganj.barisal.gov.bd', 1, NULL, NULL),
(252, NULL, 'Wazirpur', 4, 33, 'উজিরপুর', 'wazirpur.barisal.gov.bd', 1, NULL, NULL),
(253, NULL, 'Banaripara', 4, 33, 'বানারীপাড়া', 'banaripara.barisal.gov.bd', 1, NULL, NULL),
(254, NULL, 'Gournadi', 4, 33, 'গৌরনদী', 'gournadi.barisal.gov.bd', 1, NULL, NULL),
(255, NULL, 'Agailjhara', 4, 33, 'আগৈলঝাড়া', 'agailjhara.barisal.gov.bd', 1, NULL, NULL),
(256, NULL, 'Mehendiganj', 4, 33, 'মেহেন্দিগঞ্জ', 'mehendiganj.barisal.gov.bd', 1, NULL, NULL),
(257, NULL, 'Muladi', 4, 33, 'মুলাদী', 'muladi.barisal.gov.bd', 1, NULL, NULL),
(258, NULL, 'Hizla', 4, 33, 'হিজলা', 'hizla.barisal.gov.bd', 1, NULL, NULL),
(259, NULL, 'Bhola Sadar', 4, 34, 'ভোলা সদর', 'sadar.bhola.gov.bd', 1, NULL, NULL),
(260, NULL, 'Borhan Sddin', 4, 34, 'বোরহান উদ্দিন', 'borhanuddin.bhola.gov.bd', 1, NULL, NULL),
(261, NULL, 'Charfesson', 4, 34, 'চরফ্যাশন', 'charfesson.bhola.gov.bd', 1, NULL, NULL),
(262, NULL, 'Doulatkhan', 4, 34, 'দৌলতখান', 'doulatkhan.bhola.gov.bd', 1, NULL, NULL),
(263, NULL, 'Monpura', 4, 34, 'মনপুরা', 'monpura.bhola.gov.bd', 1, NULL, NULL),
(264, NULL, 'Tazumuddin', 4, 34, 'তজুমদ্দিন', 'tazumuddin.bhola.gov.bd', 1, NULL, NULL),
(265, NULL, 'Lalmohan', 4, 34, 'লালমোহন', 'lalmohan.bhola.gov.bd', 1, NULL, NULL),
(266, NULL, 'Amtali', 4, 35, 'আমতলী', 'amtali.barguna.gov.bd', 1, NULL, NULL),
(267, NULL, 'Barguna Sadar', 4, 35, 'বরগুনা সদর', 'sadar.barguna.gov.bd', 1, NULL, NULL),
(268, NULL, 'Betagi', 4, 35, 'বেতাগী', 'betagi.barguna.gov.bd', 1, NULL, NULL),
(269, NULL, 'Bamna', 4, 35, 'বামনা', 'bamna.barguna.gov.bd', 1, NULL, NULL),
(270, NULL, 'Pathorghata', 4, 35, 'পাথরঘাটা', 'pathorghata.barguna.gov.bd', 1, NULL, NULL),
(271, NULL, 'Taltali', 4, 35, 'তালতলি', 'taltali.barguna.gov.bd', 1, NULL, NULL),
(272, NULL, 'Balaganj', 5, 36, 'বালাগঞ্জ', 'balaganj.sylhet.gov.bd', 1, NULL, NULL),
(273, NULL, 'Beanibazar', 5, 36, 'বিয়ানীবাজার', 'beanibazar.sylhet.gov.bd', 1, NULL, NULL),
(274, NULL, 'Bishwanath', 5, 36, 'বিশ্বনাথ', 'bishwanath.sylhet.gov.bd', 1, NULL, NULL),
(275, NULL, 'Companiganj', 5, 36, 'কোম্পানীগঞ্জ', 'companiganj.sylhet.gov.bd', 1, NULL, NULL),
(276, NULL, 'Fenchuganj', 5, 36, 'ফেঞ্চুগঞ্জ', 'fenchuganj.sylhet.gov.bd', 1, NULL, NULL),
(277, NULL, 'Golapganj', 5, 36, 'গোলাপগঞ্জ', 'golapganj.sylhet.gov.bd', 1, NULL, NULL),
(278, NULL, 'Gowainghat', 5, 36, 'গোয়াইনঘাট', 'gowainghat.sylhet.gov.bd', 1, NULL, NULL),
(279, NULL, 'Jaintiapur', 5, 36, 'জৈন্তাপুর', 'jaintiapur.sylhet.gov.bd', 1, NULL, NULL),
(280, NULL, 'Kanaighat', 5, 36, 'কানাইঘাট', 'kanaighat.sylhet.gov.bd', 1, NULL, NULL),
(281, NULL, 'Sylhet Sadar', 5, 36, 'সিলেট সদর', 'sylhetsadar.sylhet.gov.bd', 1, NULL, NULL),
(282, NULL, 'Zakiganj', 5, 36, 'জকিগঞ্জ', 'zakiganj.sylhet.gov.bd', 1, NULL, NULL),
(283, NULL, 'Dakshinsurma', 5, 36, 'দক্ষিণ সুরমা', 'dakshinsurma.sylhet.gov.bd', 1, NULL, NULL),
(284, NULL, 'Osmaninagar', 5, 36, 'ওসমানী নগর', 'osmaninagar.sylhet.gov.bd', 1, NULL, NULL),
(285, NULL, 'Barlekha', 5, 37, 'বড়লেখা', 'barlekha.moulvibazar.gov.bd', 1, NULL, NULL),
(286, NULL, 'Kamolganj', 5, 37, 'কমলগঞ্জ', 'kamolganj.moulvibazar.gov.bd', 1, NULL, NULL),
(287, NULL, 'Kulaura', 5, 37, 'কুলাউড়া', 'kulaura.moulvibazar.gov.bd', 1, NULL, NULL),
(288, NULL, 'Moulvibazar Sadar', 5, 37, 'মৌলভীবাজার সদর', 'moulvibazarsadar.moulvibazar.gov.bd', 1, NULL, NULL),
(289, NULL, 'Rajnagar', 5, 37, 'রাজনগর', 'rajnagar.moulvibazar.gov.bd', 1, NULL, NULL),
(290, NULL, 'Sreemangal', 5, 37, 'শ্রীমঙ্গল', 'sreemangal.moulvibazar.gov.bd', 1, NULL, NULL),
(291, NULL, 'Juri', 5, 37, 'জুড়ী', 'juri.moulvibazar.gov.bd', 1, NULL, NULL),
(292, NULL, 'Nabiganj', 5, 38, 'নবীগঞ্জ', 'nabiganj.habiganj.gov.bd', 1, NULL, NULL),
(293, NULL, 'Bahubal', 5, 38, 'বাহুবল', 'bahubal.habiganj.gov.bd', 1, NULL, NULL),
(294, NULL, 'Ajmiriganj', 5, 38, 'আজমিরীগঞ্জ', 'ajmiriganj.habiganj.gov.bd', 1, NULL, NULL),
(295, NULL, 'Baniachong', 5, 38, 'বানিয়াচং', 'baniachong.habiganj.gov.bd', 1, NULL, NULL),
(296, NULL, 'Lakhai', 5, 38, 'লাখাই', 'lakhai.habiganj.gov.bd', 1, NULL, NULL),
(297, NULL, 'Chunarughat', 5, 38, 'চুনারুঘাট', 'chunarughat.habiganj.gov.bd', 1, NULL, NULL),
(298, NULL, 'Habiganj Sadar', 5, 38, 'হবিগঞ্জ সদর', 'habiganjsadar.habiganj.gov.bd', 1, NULL, NULL),
(299, NULL, 'Madhabpur', 5, 38, 'মাধবপুর', 'madhabpur.habiganj.gov.bd', 1, NULL, NULL),
(300, NULL, 'Sunamganj Sadar', 5, 39, 'সুনামগঞ্জ সদর', 'sadar.sunamganj.gov.bd', 1, NULL, NULL),
(301, NULL, 'South Sunamganj', 5, 39, 'দক্ষিণ সুনামগঞ্জ', 'southsunamganj.sunamganj.gov.bd', 1, NULL, NULL),
(302, NULL, 'Bishwambarpur', 5, 39, 'বিশ্বম্ভরপুর', 'bishwambarpur.sunamganj.gov.bd', 1, NULL, NULL),
(303, NULL, 'Chhatak', 5, 39, 'ছাতক', 'chhatak.sunamganj.gov.bd', 1, NULL, NULL),
(304, NULL, 'Jagannathpur', 5, 39, 'জগন্নাথপুর', 'jagannathpur.sunamganj.gov.bd', 1, NULL, NULL),
(305, NULL, 'Dowarabazar', 5, 39, 'দোয়ারাবাজার', 'dowarabazar.sunamganj.gov.bd', 1, NULL, NULL),
(306, NULL, 'Tahirpur', 5, 39, 'তাহিরপুর', 'tahirpur.sunamganj.gov.bd', 1, NULL, NULL),
(307, NULL, 'Dharmapasha', 5, 39, 'ধর্মপাশা', 'dharmapasha.sunamganj.gov.bd', 1, NULL, NULL),
(308, NULL, 'Jamalganj', 5, 39, 'জামালগঞ্জ', 'jamalganj.sunamganj.gov.bd', 1, NULL, NULL),
(309, NULL, 'Shalla', 5, 39, 'শাল্লা', 'shalla.sunamganj.gov.bd', 1, NULL, NULL),
(310, NULL, 'Derai', 5, 39, 'দিরাই', 'derai.sunamganj.gov.bd', 1, NULL, NULL),
(311, NULL, 'Belabo', 6, 40, 'বেলাবো', 'belabo.narsingdi.gov.bd', 1, NULL, NULL),
(312, NULL, 'Monohardi', 6, 40, 'মনোহরদী', 'monohardi.narsingdi.gov.bd', 1, NULL, NULL),
(313, NULL, 'Narsingdi Sadar', 6, 40, 'নরসিংদী সদর', 'narsingdisadar.narsingdi.gov.bd', 1, NULL, NULL),
(314, NULL, 'Palash', 6, 40, 'পলাশ', 'palash.narsingdi.gov.bd', 1, NULL, NULL),
(315, NULL, 'Raipura', 6, 40, 'রায়পুরা', 'raipura.narsingdi.gov.bd', 1, NULL, NULL),
(316, NULL, 'Shibpur', 6, 40, 'শিবপুর', 'shibpur.narsingdi.gov.bd', 1, NULL, NULL),
(317, NULL, 'Kaliganj', 6, 41, 'কালীগঞ্জ', 'kaliganj.gazipur.gov.bd', 1, NULL, NULL),
(318, NULL, 'Kaliakair', 6, 41, 'কালিয়াকৈর', 'kaliakair.gazipur.gov.bd', 1, NULL, NULL),
(319, NULL, 'Kapasia', 6, 41, 'কাপাসিয়া', 'kapasia.gazipur.gov.bd', 1, NULL, NULL),
(320, NULL, 'Gazipur Sadar', 6, 41, 'গাজীপুর সদর', 'sadar.gazipur.gov.bd', 1, NULL, NULL),
(321, NULL, 'Sreepur', 6, 41, 'শ্রীপুর', 'sreepur.gazipur.gov.bd', 1, NULL, NULL),
(322, NULL, 'Shariatpur Sadar', 6, 42, 'শরিয়তপুর সদর', 'sadar.shariatpur.gov.bd', 1, NULL, NULL),
(323, NULL, 'Naria', 6, 42, 'নড়িয়া', 'naria.shariatpur.gov.bd', 1, NULL, NULL),
(324, NULL, 'Zajira', 6, 42, 'জাজিরা', 'zajira.shariatpur.gov.bd', 1, NULL, NULL),
(325, NULL, 'Gosairhat', 6, 42, 'গোসাইরহাট', 'gosairhat.shariatpur.gov.bd', 1, NULL, NULL),
(326, NULL, 'Bhedarganj', 6, 42, 'ভেদরগঞ্জ', 'bhedarganj.shariatpur.gov.bd', 1, NULL, NULL),
(327, NULL, 'Damudya', 6, 42, 'ডামুড্যা', 'damudya.shariatpur.gov.bd', 1, NULL, NULL),
(328, NULL, 'Araihazar', 6, 43, 'আড়াইহাজার', 'araihazar.narayanganj.gov.bd', 1, NULL, NULL),
(329, NULL, 'Bandar', 6, 43, 'বন্দর', 'bandar.narayanganj.gov.bd', 1, NULL, NULL),
(330, NULL, 'Narayanganj Sadar', 6, 43, 'নারায়নগঞ্জ সদর', 'narayanganjsadar.narayanganj.gov.bd', 1, NULL, NULL),
(331, NULL, 'Rupganj', 6, 43, 'রূপগঞ্জ', 'rupganj.narayanganj.gov.bd', 1, NULL, NULL),
(332, NULL, 'Sonargaon', 6, 43, 'সোনারগাঁ', 'sonargaon.narayanganj.gov.bd', 1, NULL, NULL),
(333, NULL, 'Basail', 6, 44, 'বাসাইল', 'basail.tangail.gov.bd', 1, NULL, NULL),
(334, NULL, 'Bhuapur', 6, 44, 'ভুয়াপুর', 'bhuapur.tangail.gov.bd', 1, NULL, NULL),
(335, NULL, 'Delduar', 6, 44, 'দেলদুয়ার', 'delduar.tangail.gov.bd', 1, NULL, NULL),
(336, NULL, 'Ghatail', 6, 44, 'ঘাটাইল', 'ghatail.tangail.gov.bd', 1, NULL, NULL),
(337, NULL, 'Gopalpur', 6, 44, 'গোপালপুর', 'gopalpur.tangail.gov.bd', 1, NULL, NULL),
(338, NULL, 'Madhupur', 6, 44, 'মধুপুর', 'madhupur.tangail.gov.bd', 1, NULL, NULL),
(339, NULL, 'Mirzapur', 6, 44, 'মির্জাপুর', 'mirzapur.tangail.gov.bd', 1, NULL, NULL),
(340, NULL, 'Nagarpur', 6, 44, 'নাগরপুর', 'nagarpur.tangail.gov.bd', 1, NULL, NULL),
(341, NULL, 'Sakhipur', 6, 44, 'সখিপুর', 'sakhipur.tangail.gov.bd', 1, NULL, NULL),
(342, NULL, 'Tangail Sadar', 6, 44, 'টাঙ্গাইল সদর', 'tangailsadar.tangail.gov.bd', 1, NULL, NULL),
(343, NULL, 'Kalihati', 6, 44, 'কালিহাতী', 'kalihati.tangail.gov.bd', 1, NULL, NULL),
(344, NULL, 'Dhanbari', 6, 44, 'ধনবাড়ী', 'dhanbari.tangail.gov.bd', 1, NULL, NULL),
(345, NULL, 'Itna', 6, 45, 'ইটনা', 'itna.kishoreganj.gov.bd', 1, NULL, NULL),
(346, NULL, 'Katiadi', 6, 45, 'কটিয়াদী', 'katiadi.kishoreganj.gov.bd', 1, NULL, NULL),
(347, NULL, 'Bhairab', 6, 45, 'ভৈরব', 'bhairab.kishoreganj.gov.bd', 1, NULL, NULL),
(348, NULL, 'Tarail', 6, 45, 'তাড়াইল', 'tarail.kishoreganj.gov.bd', 1, NULL, NULL),
(349, NULL, 'Hossainpur', 6, 45, 'হোসেনপুর', 'hossainpur.kishoreganj.gov.bd', 1, NULL, NULL),
(350, NULL, 'Pakundia', 6, 45, 'পাকুন্দিয়া', 'pakundia.kishoreganj.gov.bd', 1, NULL, NULL),
(351, NULL, 'Kuliarchar', 6, 45, 'কুলিয়ারচর', 'kuliarchar.kishoreganj.gov.bd', 1, NULL, NULL),
(352, NULL, 'Kishoreganj Sadar', 6, 45, 'কিশোরগঞ্জ সদর', 'kishoreganjsadar.kishoreganj.gov.bd', 1, NULL, NULL),
(353, NULL, 'Karimgonj', 6, 45, 'করিমগঞ্জ', 'karimgonj.kishoreganj.gov.bd', 1, NULL, NULL),
(354, NULL, 'Bajitpur', 6, 45, 'বাজিতপুর', 'bajitpur.kishoreganj.gov.bd', 1, NULL, NULL),
(355, NULL, 'Austagram', 6, 45, 'অষ্টগ্রাম', 'austagram.kishoreganj.gov.bd', 1, NULL, NULL),
(356, NULL, 'Mithamoin', 6, 45, 'মিঠামইন', 'mithamoin.kishoreganj.gov.bd', 1, NULL, NULL),
(357, NULL, 'Nikli', 6, 45, 'নিকলী', 'nikli.kishoreganj.gov.bd', 1, NULL, NULL),
(358, NULL, 'Harirampur', 6, 46, 'হরিরামপুর', 'harirampur.manikganj.gov.bd', 1, NULL, NULL),
(359, NULL, 'Saturia', 6, 46, 'সাটুরিয়া', 'saturia.manikganj.gov.bd', 1, NULL, NULL),
(360, NULL, 'Manikganj Sadar', 6, 46, 'মানিকগঞ্জ সদর', 'sadar.manikganj.gov.bd', 1, NULL, NULL),
(361, NULL, 'Gior', 6, 46, 'ঘিওর', 'gior.manikganj.gov.bd', 1, NULL, NULL),
(362, NULL, 'Shibaloy', 6, 46, 'শিবালয়', 'shibaloy.manikganj.gov.bd', 1, NULL, NULL),
(363, NULL, 'Doulatpur', 6, 46, 'দৌলতপুর', 'doulatpur.manikganj.gov.bd', 1, NULL, NULL),
(364, NULL, 'Singiar', 6, 46, 'সিংগাইর', 'singiar.manikganj.gov.bd', 1, NULL, NULL),
(365, NULL, 'Savar', 6, 47, 'সাভার', 'savar.dhaka.gov.bd', 1, NULL, NULL),
(366, NULL, 'Dhamrai', 6, 47, 'ধামরাই', 'dhamrai.dhaka.gov.bd', 1, NULL, NULL),
(367, NULL, 'Keraniganj', 6, 47, 'কেরাণীগঞ্জ', 'keraniganj.dhaka.gov.bd', 1, NULL, NULL),
(368, NULL, 'Nawabganj', 6, 47, 'নবাবগঞ্জ', 'nawabganj.dhaka.gov.bd', 1, NULL, NULL),
(369, NULL, 'Dohar', 6, 47, 'দোহার', 'dohar.dhaka.gov.bd', 1, NULL, NULL),
(370, NULL, 'Munshiganj Sadar', 6, 48, 'মুন্সিগঞ্জ সদর', 'sadar.munshiganj.gov.bd', 1, NULL, NULL),
(371, NULL, 'Sreenagar', 6, 48, 'শ্রীনগর', 'sreenagar.munshiganj.gov.bd', 1, NULL, NULL),
(372, NULL, 'Sirajdikhan', 6, 48, 'সিরাজদিখান', 'sirajdikhan.munshiganj.gov.bd', 1, NULL, NULL),
(373, NULL, 'Louhajanj', 6, 48, 'লৌহজং', 'louhajanj.munshiganj.gov.bd', 1, NULL, NULL),
(374, NULL, 'Gajaria', 6, 48, 'গজারিয়া', 'gajaria.munshiganj.gov.bd', 1, NULL, NULL),
(375, NULL, 'Tongibari', 6, 48, 'টংগীবাড়ি', 'tongibari.munshiganj.gov.bd', 1, NULL, NULL),
(376, NULL, 'Rajbari Sadar', 6, 49, 'রাজবাড়ী সদর', 'sadar.rajbari.gov.bd', 1, NULL, NULL),
(377, NULL, 'Goalanda', 6, 49, 'গোয়ালন্দ', 'goalanda.rajbari.gov.bd', 1, NULL, NULL),
(378, NULL, 'Pangsa', 6, 49, 'পাংশা', 'pangsa.rajbari.gov.bd', 1, NULL, NULL),
(379, NULL, 'Baliakandi', 6, 49, 'বালিয়াকান্দি', 'baliakandi.rajbari.gov.bd', 1, NULL, NULL),
(380, NULL, 'Kalukhali', 6, 49, 'কালুখালী', 'kalukhali.rajbari.gov.bd', 1, NULL, NULL),
(381, NULL, 'Madaripur Sadar', 6, 50, 'মাদারীপুর সদর', 'sadar.madaripur.gov.bd', 1, NULL, NULL),
(382, NULL, 'Shibchar', 6, 50, 'শিবচর', 'shibchar.madaripur.gov.bd', 1, NULL, NULL),
(383, NULL, 'Kalkini', 6, 50, 'কালকিনি', 'kalkini.madaripur.gov.bd', 1, NULL, NULL),
(384, NULL, 'Rajoir', 6, 50, 'রাজৈর', 'rajoir.madaripur.gov.bd', 1, NULL, NULL),
(385, NULL, 'Gopalganj Sadar', 6, 51, 'গোপালগঞ্জ সদর', 'sadar.gopalganj.gov.bd', 1, NULL, NULL),
(386, NULL, 'Kashiani', 6, 51, 'কাশিয়ানী', 'kashiani.gopalganj.gov.bd', 1, NULL, NULL),
(387, NULL, 'Tungipara', 6, 51, 'টুংগীপাড়া', 'tungipara.gopalganj.gov.bd', 1, NULL, NULL),
(388, NULL, 'Kotalipara', 6, 51, 'কোটালীপাড়া', 'kotalipara.gopalganj.gov.bd', 1, NULL, NULL),
(389, NULL, 'Muksudpur', 6, 51, 'মুকসুদপুর', 'muksudpur.gopalganj.gov.bd', 1, NULL, NULL),
(390, NULL, 'Faridpur Sadar', 6, 52, 'ফরিদপুর সদর', 'sadar.faridpur.gov.bd', 1, NULL, NULL),
(391, NULL, 'Alfadanga', 6, 52, 'আলফাডাঙ্গা', 'alfadanga.faridpur.gov.bd', 1, NULL, NULL),
(392, NULL, 'Boalmari', 6, 52, 'বোয়ালমারী', 'boalmari.faridpur.gov.bd', 1, NULL, NULL),
(393, NULL, 'Sadarpur', 6, 52, 'সদরপুর', 'sadarpur.faridpur.gov.bd', 1, NULL, NULL),
(394, NULL, 'Nagarkanda', 6, 52, 'নগরকান্দা', 'nagarkanda.faridpur.gov.bd', 1, NULL, NULL),
(395, NULL, 'Bhanga', 6, 52, 'ভাঙ্গা', 'bhanga.faridpur.gov.bd', 1, NULL, NULL),
(396, NULL, 'Charbhadrasan', 6, 52, 'চরভদ্রাসন', 'charbhadrasan.faridpur.gov.bd', 1, NULL, NULL),
(397, NULL, 'Madhukhali', 6, 52, 'মধুখালী', 'madhukhali.faridpur.gov.bd', 1, NULL, NULL),
(398, NULL, 'Saltha', 6, 52, 'সালথা', 'saltha.faridpur.gov.bd', 1, NULL, NULL),
(399, NULL, 'Panchagarh Sadar', 7, 53, 'পঞ্চগড় সদর', 'panchagarhsadar.panchagarh.gov.bd', 1, NULL, NULL),
(400, NULL, 'Debiganj', 7, 53, 'দেবীগঞ্জ', 'debiganj.panchagarh.gov.bd', 1, NULL, NULL),
(401, NULL, 'Boda', 7, 53, 'বোদা', 'boda.panchagarh.gov.bd', 1, NULL, NULL),
(402, NULL, 'Atwari', 7, 53, 'আটোয়ারী', 'atwari.panchagarh.gov.bd', 1, NULL, NULL),
(403, NULL, 'Tetulia', 7, 53, 'তেতুলিয়া', 'tetulia.panchagarh.gov.bd', 1, NULL, NULL),
(404, NULL, 'Nawabganj', 7, 54, 'নবাবগঞ্জ', 'nawabganj.dinajpur.gov.bd', 1, NULL, NULL),
(405, NULL, 'Birganj', 7, 54, 'বীরগঞ্জ', 'birganj.dinajpur.gov.bd', 1, NULL, NULL),
(406, NULL, 'Ghoraghat', 7, 54, 'ঘোড়াঘাট', 'ghoraghat.dinajpur.gov.bd', 1, NULL, NULL),
(407, NULL, 'Birampur', 7, 54, 'বিরামপুর', 'birampur.dinajpur.gov.bd', 1, NULL, NULL),
(408, NULL, 'Parbatipur', 7, 54, 'পার্বতীপুর', 'parbatipur.dinajpur.gov.bd', 1, NULL, NULL),
(409, NULL, 'Bochaganj', 7, 54, 'বোচাগঞ্জ', 'bochaganj.dinajpur.gov.bd', 1, NULL, NULL),
(410, NULL, 'Kaharol', 7, 54, 'কাহারোল', 'kaharol.dinajpur.gov.bd', 1, NULL, NULL),
(411, NULL, 'Fulbari', 7, 54, 'ফুলবাড়ী', 'fulbari.dinajpur.gov.bd', 1, NULL, NULL),
(412, NULL, 'Dinajpur Sadar', 7, 54, 'দিনাজপুর সদর', 'dinajpursadar.dinajpur.gov.bd', 1, NULL, NULL),
(413, NULL, 'Hakimpur', 7, 54, 'হাকিমপুর', 'hakimpur.dinajpur.gov.bd', 1, NULL, NULL),
(414, NULL, 'Khansama', 7, 54, 'খানসামা', 'khansama.dinajpur.gov.bd', 1, NULL, NULL),
(415, NULL, 'Birol', 7, 54, 'বিরল', 'birol.dinajpur.gov.bd', 1, NULL, NULL),
(416, NULL, 'Chirirbandar', 7, 54, 'চিরিরবন্দর', 'chirirbandar.dinajpur.gov.bd', 1, NULL, NULL),
(417, NULL, 'Lalmonirhat Sadar', 7, 55, 'লালমনিরহাট সদর', 'sadar.lalmonirhat.gov.bd', 1, NULL, NULL),
(418, NULL, 'Kaliganj', 7, 55, 'কালীগঞ্জ', 'kaliganj.lalmonirhat.gov.bd', 1, NULL, NULL),
(419, NULL, 'Hatibandha', 7, 55, 'হাতীবান্ধা', 'hatibandha.lalmonirhat.gov.bd', 1, NULL, NULL),
(420, NULL, 'Patgram', 7, 55, 'পাটগ্রাম', 'patgram.lalmonirhat.gov.bd', 1, NULL, NULL),
(421, NULL, 'Aditmari', 7, 55, 'আদিতমারী', 'aditmari.lalmonirhat.gov.bd', 1, NULL, NULL),
(422, NULL, 'Syedpur', 7, 56, 'সৈয়দপুর', 'syedpur.nilphamari.gov.bd', 1, NULL, NULL),
(423, NULL, 'Domar', 7, 56, 'ডোমার', 'domar.nilphamari.gov.bd', 1, NULL, NULL),
(424, NULL, 'Dimla', 7, 56, 'ডিমলা', 'dimla.nilphamari.gov.bd', 1, NULL, NULL),
(425, NULL, 'Jaldhaka', 7, 56, 'জলঢাকা', 'jaldhaka.nilphamari.gov.bd', 1, NULL, NULL),
(426, NULL, 'Kishorganj', 7, 56, 'কিশোরগঞ্জ', 'kishorganj.nilphamari.gov.bd', 1, NULL, NULL),
(427, NULL, 'Nilphamari Sadar', 7, 56, 'নীলফামারী সদর', 'nilphamarisadar.nilphamari.gov.bd', 1, NULL, NULL),
(428, NULL, 'Sadullapur', 7, 57, 'সাদুল্লাপুর', 'sadullapur.gaibandha.gov.bd', 1, NULL, NULL),
(429, NULL, 'Gaibandha Sadar', 7, 57, 'গাইবান্ধা সদর', 'gaibandhasadar.gaibandha.gov.bd', 1, NULL, NULL),
(430, NULL, 'Palashbari', 7, 57, 'পলাশবাড়ী', 'palashbari.gaibandha.gov.bd', 1, NULL, NULL),
(431, NULL, 'Saghata', 7, 57, 'সাঘাটা', 'saghata.gaibandha.gov.bd', 1, NULL, NULL),
(432, NULL, 'Gobindaganj', 7, 57, 'গোবিন্দগঞ্জ', 'gobindaganj.gaibandha.gov.bd', 1, NULL, NULL),
(433, NULL, 'Sundarganj', 7, 57, 'সুন্দরগঞ্জ', 'sundarganj.gaibandha.gov.bd', 1, NULL, NULL),
(434, NULL, 'Phulchari', 7, 57, 'ফুলছড়ি', 'phulchari.gaibandha.gov.bd', 1, NULL, NULL),
(435, NULL, 'Thakurgaon Sadar', 7, 58, 'ঠাকুরগাঁও সদর', 'thakurgaonsadar.thakurgaon.gov.bd', 1, NULL, NULL),
(436, NULL, 'Pirganj', 7, 58, 'পীরগঞ্জ', 'pirganj.thakurgaon.gov.bd', 1, NULL, NULL),
(437, NULL, 'Ranisankail', 7, 58, 'রাণীশংকৈল', 'ranisankail.thakurgaon.gov.bd', 1, NULL, NULL),
(438, NULL, 'Haripur', 7, 58, 'হরিপুর', 'haripur.thakurgaon.gov.bd', 1, NULL, NULL),
(439, NULL, 'Baliadangi', 7, 58, 'বালিয়াডাঙ্গী', 'baliadangi.thakurgaon.gov.bd', 1, NULL, NULL),
(440, NULL, 'Rangpur Sadar', 7, 59, 'রংপুর সদর', 'rangpursadar.rangpur.gov.bd', 1, NULL, NULL),
(441, NULL, 'Gangachara', 7, 59, 'গংগাচড়া', 'gangachara.rangpur.gov.bd', 1, NULL, NULL),
(442, NULL, 'Taragonj', 7, 59, 'তারাগঞ্জ', 'taragonj.rangpur.gov.bd', 1, NULL, NULL),
(443, NULL, 'Badargonj', 7, 59, 'বদরগঞ্জ', 'badargonj.rangpur.gov.bd', 1, NULL, NULL),
(444, NULL, 'Mithapukur', 7, 59, 'মিঠাপুকুর', 'mithapukur.rangpur.gov.bd', 1, NULL, NULL),
(445, NULL, 'Pirgonj', 7, 59, 'পীরগঞ্জ', 'pirgonj.rangpur.gov.bd', 1, NULL, NULL),
(446, NULL, 'Kaunia', 7, 59, 'কাউনিয়া', 'kaunia.rangpur.gov.bd', 1, NULL, NULL),
(447, NULL, 'Pirgacha', 7, 59, 'পীরগাছা', 'pirgacha.rangpur.gov.bd', 1, NULL, NULL),
(448, NULL, 'Kurigram Sadar', 7, 60, 'কুড়িগ্রাম সদর', 'kurigramsadar.kurigram.gov.bd', 1, NULL, NULL),
(449, NULL, 'Nageshwari', 7, 60, 'নাগেশ্বরী', 'nageshwari.kurigram.gov.bd', 1, NULL, NULL),
(450, NULL, 'Bhurungamari', 7, 60, 'ভুরুঙ্গামারী', 'bhurungamari.kurigram.gov.bd', 1, NULL, NULL),
(451, NULL, 'Phulbari', 7, 60, 'ফুলবাড়ী', 'phulbari.kurigram.gov.bd', 1, NULL, NULL),
(452, NULL, 'Rajarhat', 7, 60, 'রাজারহাট', 'rajarhat.kurigram.gov.bd', 1, NULL, NULL),
(453, NULL, 'Ulipur', 7, 60, 'উলিপুর', 'ulipur.kurigram.gov.bd', 1, NULL, NULL),
(454, NULL, 'Chilmari', 7, 60, 'চিলমারী', 'chilmari.kurigram.gov.bd', 1, NULL, NULL),
(455, NULL, 'Rowmari', 7, 60, 'রৌমারী', 'rowmari.kurigram.gov.bd', 1, NULL, NULL),
(456, NULL, 'Charrajibpur', 7, 60, 'চর রাজিবপুর', 'charrajibpur.kurigram.gov.bd', 1, NULL, NULL),
(457, NULL, 'Sherpur Sadar', 8, 61, 'শেরপুর সদর', 'sherpursadar.sherpur.gov.bd', 1, NULL, NULL),
(458, NULL, 'Nalitabari', 8, 61, 'নালিতাবাড়ী', 'nalitabari.sherpur.gov.bd', 1, NULL, NULL),
(459, NULL, 'Sreebordi', 8, 61, 'শ্রীবরদী', 'sreebordi.sherpur.gov.bd', 1, NULL, NULL),
(460, NULL, 'Nokla', 8, 61, 'নকলা', 'nokla.sherpur.gov.bd', 1, NULL, NULL),
(461, NULL, 'Jhenaigati', 8, 61, 'ঝিনাইগাতী', 'jhenaigati.sherpur.gov.bd', 1, NULL, NULL),
(462, NULL, 'Fulbaria', 8, 62, 'ফুলবাড়ীয়া', 'fulbaria.mymensingh.gov.bd', 1, NULL, NULL),
(463, NULL, 'Trishal', 8, 62, 'ত্রিশাল', 'trishal.mymensingh.gov.bd', 1, NULL, NULL),
(464, NULL, 'Bhaluka', 8, 62, 'ভালুকা', 'bhaluka.mymensingh.gov.bd', 1, NULL, NULL),
(465, NULL, 'Muktagacha', 8, 62, 'মুক্তাগাছা', 'muktagacha.mymensingh.gov.bd', 1, NULL, NULL),
(466, NULL, 'Mymensingh Sadar', 8, 62, 'ময়মনসিংহ সদর', 'mymensinghsadar.mymensingh.gov.bd', 1, NULL, NULL),
(467, NULL, 'Dhobaura', 8, 62, 'ধোবাউড়া', 'dhobaura.mymensingh.gov.bd', 1, NULL, NULL),
(468, NULL, 'Phulpur', 8, 62, 'ফুলপুর', 'phulpur.mymensingh.gov.bd', 1, NULL, NULL),
(469, NULL, 'Haluaghat', 8, 62, 'হালুয়াঘাট', 'haluaghat.mymensingh.gov.bd', 1, NULL, NULL),
(470, NULL, 'Gouripur', 8, 62, 'গৌরীপুর', 'gouripur.mymensingh.gov.bd', 1, NULL, NULL),
(471, NULL, 'Gafargaon', 8, 62, 'গফরগাঁও', 'gafargaon.mymensingh.gov.bd', 1, NULL, NULL),
(472, NULL, 'Iswarganj', 8, 62, 'ঈশ্বরগঞ্জ', 'iswarganj.mymensingh.gov.bd', 1, NULL, NULL),
(473, NULL, 'Nandail', 8, 62, 'নান্দাইল', 'nandail.mymensingh.gov.bd', 1, NULL, NULL),
(474, NULL, 'Tarakanda', 8, 62, 'তারাকান্দা', 'tarakanda.mymensingh.gov.bd', 1, NULL, NULL),
(475, NULL, 'Jamalpur Sadar', 8, 63, 'জামালপুর সদর', 'jamalpursadar.jamalpur.gov.bd', 1, NULL, NULL),
(476, NULL, 'Melandah', 8, 63, 'মেলান্দহ', 'melandah.jamalpur.gov.bd', 1, NULL, NULL),
(477, NULL, 'Islampur', 8, 63, 'ইসলামপুর', 'islampur.jamalpur.gov.bd', 1, NULL, NULL),
(478, NULL, 'Dewangonj', 8, 63, 'দেওয়ানগঞ্জ', 'dewangonj.jamalpur.gov.bd', 1, NULL, NULL),
(479, NULL, 'Sarishabari', 8, 63, 'সরিষাবাড়ী', 'sarishabari.jamalpur.gov.bd', 1, NULL, NULL),
(480, NULL, 'Madarganj', 8, 63, 'মাদারগঞ্জ', 'madarganj.jamalpur.gov.bd', 1, NULL, NULL),
(481, NULL, 'Bokshiganj', 8, 63, 'বকশীগঞ্জ', 'bokshiganj.jamalpur.gov.bd', 1, NULL, NULL),
(482, NULL, 'Barhatta', 8, 64, 'বারহাট্টা', 'barhatta.netrokona.gov.bd', 1, NULL, NULL),
(483, NULL, 'Durgapur', 8, 64, 'দুর্গাপুর', 'durgapur.netrokona.gov.bd', 1, NULL, NULL),
(484, NULL, 'Kendua', 8, 64, 'কেন্দুয়া', 'kendua.netrokona.gov.bd', 1, NULL, NULL),
(485, NULL, 'Atpara', 8, 64, 'আটপাড়া', 'atpara.netrokona.gov.bd', 1, NULL, NULL),
(486, NULL, 'Madan', 8, 64, 'মদন', 'madan.netrokona.gov.bd', 1, NULL, NULL),
(487, NULL, 'Khaliajuri', 8, 64, 'খালিয়াজুরী', 'khaliajuri.netrokona.gov.bd', 1, NULL, NULL),
(488, NULL, 'Kalmakanda', 8, 64, 'কলমাকান্দা', 'kalmakanda.netrokona.gov.bd', 1, NULL, NULL),
(489, NULL, 'Mohongonj', 8, 64, 'মোহনগঞ্জ', 'mohongonj.netrokona.gov.bd', 1, NULL, NULL),
(490, NULL, 'Purbadhala', 8, 64, 'পূর্বধলা', 'purbadhala.netrokona.gov.bd', 1, NULL, NULL),
(491, NULL, 'Netrokona Sadar', 8, 64, 'নেত্রকোণা সদর', 'netrokonasadar.netrokona.gov.bd', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `image` text COLLATE utf8mb4_unicode_ci,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` text COLLATE utf8mb4_unicode_ci,
  `role_id` bigint(20) NOT NULL DEFAULT '3',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `phone`, `email_verified_at`, `address`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `image`, `remember_token`, `current_team_id`, `profile_photo_path`, `role_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', NULL, 'admin@gmail.com', NULL, NULL, NULL, '$2y$10$rqsqgxnUQhe6qhyynGHbeuh/XSEnu45vwqTBBxF2hDkTkUPNJHKoC', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
