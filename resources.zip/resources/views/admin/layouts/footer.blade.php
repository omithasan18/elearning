<!-- /.content-wrapper -->
<footer class="main-footer">
    <strong>Copyright &copy; 2014-2019 <a href="">{{ config('app.name', 'Laravel') }}</a>.</strong>
      All rights reserved.
</footer>