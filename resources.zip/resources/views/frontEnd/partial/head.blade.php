<!-- fonts (Poppins) -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<!-- ALL CSS -->
<link rel="stylesheet" href="{{asset('frontend/css/slick.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/slick-theme.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/all.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/indextw.css')}}"/>
<link rel="stylesheet" href="{{asset('frontend/css/tailwind.css')}}">