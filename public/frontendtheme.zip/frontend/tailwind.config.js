const defaultTheme = require('tailwindcss/defaultTheme');

module.exports = {
  content: [
    './src/**/*.css',
    './*.html'
  ],
  theme: {
    "fontFamily": {
      "poppins": ["Poppins", "sans-serif"],
    },
    screens: {
      'xs': '475px',
      ...defaultTheme.screens,
    },
    extend: {
      colors: {
        'primary': '#21a7d0',
        "secondary": "#273c66",
      },
    },
  },
  plugins: [
    require('@tailwindcss/line-clamp'),
  ],
}
