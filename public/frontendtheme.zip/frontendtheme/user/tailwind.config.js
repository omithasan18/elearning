module.exports = {
  content: [
    './src/**/*.css',
    './*.html'
  ],
  theme: {
    "fontFamily": {
      "poppins": ["Poppins", "sans-serif"],
    },
    extend: {
      colors: {
        'primary': '#21a7d0',
        "secondary": "#273c66",
      },
    },
  },
  plugins: [
    require('@tailwindcss/line-clamp'),
  ],
}
